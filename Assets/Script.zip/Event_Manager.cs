﻿using UnityEngine;
using System.Collections;

public class Event_Manager : Singleton<Event_Manager>
{
    //Object[] Event_obj;
    enum Event_ { ride_car, cross_line, trash, sunstroke };

    public void Start()
    {
        Event_Manager.Instance;
    }

    public void Update()
    {
    }

    void character_event(Event_ event_)
    {
        switch (event_)
        {
            case Event_.ride_car:
                {
                    //호출하면 차가 위치 구해서 박는거.
                    break;
                }

            case Event_.cross_line:
                {
                    //호출하면 차가 와서 박는걸로.
                    break;
                }

            case Event_.trash:
                {
                    //위에서 철근이 떨어지는거.
                    break;
                }

            case Event_.sunstroke:
                {
                    //아이스크림을 일정시간 먹지 않을경우 캐릭터가 죽는.
                    break;
                }
            default:
                return;
        }
    }

    //파편 움직이게 하는거 여길로 옴겨올까 하는데. 그냥 이벤트만 담당하는게 나을거같기도하고..
}

